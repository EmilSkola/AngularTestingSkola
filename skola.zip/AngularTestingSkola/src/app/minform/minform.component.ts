import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: "app-minform",
  templateUrl: './minform.component.html'
})
export class MinformComponent{

    contactForm: FormGroup;
    contact = {
        namn: ''
    };
    submitted = false;

    constructor() {
        this.createForm();
    }

    createForm(): void {
        this.contactForm = new FormGroup({
            'namn': new FormControl(this.contact.namn, [
                Validators.required,
                Validators.minLength(4)
            ])
        });
    }

    onSubmit(): void {
        this.submitted = true;
    }
}
