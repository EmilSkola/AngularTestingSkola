# UnitTest
1.cd vart angular projekte finns
2.npm install
3.ng test
4.Öppna chrome http://localhost:9876/
5.Tryck på DEBUG
6.Se unit test köras
